<?php
//author:saravana
//date:09/10/2019
class controller{
	private $model;
	private $view;
	private $id;
	private $module;

public function __construct(){
	$this->model = $_REQUEST['model'];
	$this->view = $_REQUEST['view'];
	$this->id = $_REQUEST['id'];
	$this->module = $_REQUEST['module'];




}

public function call_update(){
	//model/model.php
	
	require_once ($this->model.'/'.$this->model.".php");
	//requiring model.php
	
	 call_user_func_array(array($this->model,$this->module), array($this->id));
}
public function call_delete(){

	//requiring model.php file
	require_once ("model/".$this->model.".php");

	
	 call_user_func_array(array($this->model,$this->module), array($this->id));
	

}


}

$obj= new controller;

if($_REQUEST['module']== 'update')
{
	//call call_update function
	$obj->call_update();

}
else{
	//calling call_delete function_exists(function_name)
	$obj->call_delete();
}





?>