<?php

//author : saravana
//date : 08/10/2019

class view{
	private $vi;
	private $model;
	private $view;
	private $id;

	

	public function viewing(){

		$this->model = $_REQUEST['model'];

		
		//require("../model/model.php");//accesing model.php from models
		require ('../'.$this->model."/".$this->model.'.php');

		//$vi=call_user_func('model::file_db'); // calling file_dp function

		$vi = call_user_func_array(array($this->model,'file_db'), array(1) );
		
		return $vi;
		
	}
	
}
$obj = new view;
$v = $obj->viewing();




?>

<!-- Html file for form handling the edit details -->
<!DOCTYPE html>
<html>
<head>
	<title>EmployeeDetails</title>
	<link rel="stylesheet" type="text/css" href="../lib/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../lib/css/font-awesome.min">
</head>
<body>
	<div class="Container">
		<div class="row">
			<div class="col-md-2">
			</div>
			<div class="col-md-8">
				<table class="table table-striped">
					<tr>
						<th>EmployeeID</th>
						<th>EmployeeName</th>
						<th>Age</th>
						<th>Mobile Number</th>
						<th>Experience</th>
						<th>Action</th>
					</tr>
					
				<?php $i=-1; foreach ($v['employees'] as $index => $obj): $i=$i+1;  ?>
					

					<tr>
						<td> <?php echo $v['employees'][$i]['EmployeeId'] ; ?> </td>
						<td> <?php echo $v['employees'][$i]['EmpName'] ; ?> </td>
						<td> <?php echo $v['employees'][$i]['Age'] ; ?> </td>
						<td> <?php echo $v['employees'][$i]['MobNum'] ; ?> </td>
						<td> <?php echo $v['employees'][$i]['Experience'] ; ?> </td>
						<td> 
								<a href="../index.php?view=view&model=model&module=update&id=<?php echo $i;?>"><button class="btn btn-xs btn-success glyphicon glyphicon-pencil"></button></a> 
								<a href="../index.php?view=view&model=model&module=delete&id=<?php echo $i;?>" ><button class="btn btn-xs btn-danger glyphicon glyphicon-remove"></button></a>
						</td>

					</tr> 

					<?php endforeach; ?>




				</table>
			</div>
			<div class="col-md-2">
			</div>
		</div>
	</div>

<div class="text-center">
	<button class="btn btn-primary" value="Export-File">ExportFile</button>


</body>

</html>
