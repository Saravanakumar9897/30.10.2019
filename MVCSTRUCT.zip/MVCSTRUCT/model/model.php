<?php
#author:saravana
#date: 08/10/2019
class model{
	private $json;

public function file_db(){
	#//getting the json file values
	$jsonfile = file_get_contents('../empdetails.json');
	$json = json_decode($jsonfile,true);
	

	return $json;

}
public function update($id){
	//to update the details
	$id = $_REQUEST['id'];
	$jsonfile = file_get_contents('empdetails.json');
	$json = json_decode($jsonfile,true);

	 
	//print_r( $json['employees'][$id] );

	$eid =  $json['employees'][$id]['EmployeeId'];
	$ename =  $json['employees'][$id]['EmpName'];
	$eage =  $json['employees'][$id]['Age'];
	$emob =  $json['employees'][$id]['MobNum'];
	$eexp =  $json['employees'][$id]['Experience'];

	//echo $eid;

	//creating form by html
	echo "<form action='model/update2.php?id=$id&ipid=$eid&model=model' method='POST' >";
	echo "<table>";
	echo "<tr>";
	echo "<td>";
	echo "<lable for=\EmployeeId value=\EmployeeId > EmployeeId </lable> </td> ";
	echo "<td>";
	echo "<input type='text' value ='$eid' name='tid' > </input> </td> ";
	echo "<td>";
	echo  "</tr>";
	echo "<tr>";
	echo "<td>";
	echo "<lable for=\EmployeeId value=\EmployeeId > EmpName </lable> </td> ";
	echo "<td>";
	echo "<input type='text' value ='$ename' name='tname'> </input> </td> ";
	echo "<td>";
	echo  "</tr>";
	echo "<tr>";
	echo "<td>";
	echo "<lable for=\EmployeeId value=\EmployeeId > Age </lable> </td> ";
	echo "<td>";
	echo "<input type='text' value ='$eage' name='tage'> </input> </td> ";
	echo "<td>";
	echo  "</tr>";
	echo "<tr>";
	echo "<td>";
	echo "<lable for=\EmployeeId value=\EmployeeId > MobNum </lable> </td> ";
	echo "<td>";
	echo "<input type='text' value ='$emob' name='tmob'> </input> </td> ";
	echo "<td>";
	echo  "</tr>";
	echo "<tr>";
	echo "<td>";
	echo "<lable for=\EmployeeId value=\EmployeeId > Experience </lable> </td> ";
	echo "<td>";
	echo "<input type='text' value ='$eexp' name='texp'> </input> </td> ";
	echo "<td>";
	echo  "</tr>";
	echo " </table>";
	
	echo "<input type='submit' > </input >";
	echo "</form>";



	


}
public function delete(){

//delete function


if (isset($_REQUEST["id"])) {

	
    $id = (int) $_REQUEST["id"];
    $all = file_get_contents('empdetails.json');
    $all = json_decode($all, true);
    $jsonfile = $all["employees"];
    $jsonfile = $jsonfile[$id];

    

    if ($jsonfile) {
        unset($all["employees"][$id]);
        $all["employees"] = array_values($all["employees"]);
        file_put_contents("empdetails.json", json_encode($all));
    }
}
 header("Location: ../MVCSTRUCT/view/view.php?model=model");

}





}

$obj1= new model;

?>