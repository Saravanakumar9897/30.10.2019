<?php
//author:saravana
//date:8/10/2019




//header("Location: ../view/view.php?model=model");


//updating details

class update1{

	public function __construct(){

if (isset($_REQUEST["id"])) {
	  	    $id = (int) $_REQUEST["id"];
	  	    $getfile = file_get_contents('../empdetails.json');
	  	    $jsonfile = json_decode($getfile, true);
	  	    $jsonfile = $jsonfile["employees"];
	  	    $jsonfile = $jsonfile[$id];
	 	}

	  		if (isset($_REQUEST["id"])) {
	  	    $id = (int) $_REQUEST["id"];
	  	    $getfile = file_get_contents('../empdetails.json');
	  	    $all = json_decode($getfile, true);
	  	    $jsonfile = $all["employees"];
	  	    $jsonfile = $jsonfile[$id];

	  	     //$post1 = isset($jsonfile[$id]["EmployeeId"]) ? $jsonfile[$id]["EmployeeId"] : $_POST['tid'];
	  	     //$post["EmpName"] = isset($jsonfile[$id]["EmpName"]) ? $jsonfile[$id]["EmpName"] : $_POST['tname'];
	  	     //$post["Age"] = isset($jsonfile[$id]["Age"]) ? $jsonfile[$id]["Age"] : $_POST['tage'];
	  	     //$post["MobNum"] = isset($jsonfile[$id]["MobNUm"]) ? $jsonfile[$id]["MobNum"] : $_POST['tmob'];
	  	     //$post["Experience"] = isset($jsonfile[$id]["Experience"]) ? $jsonfile[$id]["Experience"] : $_POST['texp'];

	  	    $post=$jsonfile;


	  	    // $post['employees'][$id]["EmployeeId"] = isset($_POST['tid']) ? $_POST['tid']:$jsonfile[$id]["EmployeeId"] ;
	  	    // $post['employees'][$id]["EmpName"] = isset($_POST['tname']) ? $_POST['tname'] :$jsonfile[$id]["EmpName"];
	  	    // $post['employees'][$id]["Age"] = isset($_POST['tage']) ? $_POST['tage'] : $jsonfile[$id]["Age"];
	  	    // $post['employees'][$id]["MobNum"] = isset( $_POST['tmob']) ?  $_POST['tmob'] : $jsonfile[$id]["MobNum"];
	  	    // $post['employees'][$id]["Experience"] = isset($_POST['texp']) ? $_POST['texp'] : $jsonfile[$id]["Experience"];
		    


      if ($jsonfile) {
      	
          unset($all["employees"][$id]);


          //$all["employees"][$id] =  array_values($post);

          // $all["employees"][$id]['EmployeeId']= $post["EmployeeId"];
          // $all["employees"][$id]['EmpName']= $post["EmpName"];
          // $all["employees"][$id]['Age']= $post["Age"];
          // $all["employees"][$id]['MobNum']= $post["MobNum"];
          // $all["employees"][$id]['Experience']= $post["Experience"];

          $all['employees'][$id]=array("EmployeeId"=>$_POST["tid"],"EmpName"=>$_POST['tname'],"Age"=>$_POST['tage'],"MobNum"=>$_POST['tmob'],"Experience"=>$_POST['texp']);

          	

          //$all["employees"] = array_values($all["employees"]);

          file_put_contents("empdetails.json", json_encode($all));
     }
	  }


}
}

$obj = new update1;






?>