<?php

//author:saravana
//date:8/10/2019






//updating details
class update2{

	 

	public function __construct(){

			if (isset($_REQUEST["id"])) {
    $id = (int) $_REQUEST["id"];
    $all = file_get_contents('../empdetails.json');
    $all = json_decode($all, true);
    $jsonfile = $all["employees"];
    $jsonfile = $jsonfile[$id];

    

    if ($jsonfile) {
        unset($json["employees"][$id]);

         $all['employees'][$id]=array("EmployeeId"=>$_POST["tid"],"EmpName"=>$_POST['tname'],"Age"=>$_POST['tage'],"MobNum"=>$_POST['tmob'],"Experience"=>$_POST['texp']);


         
        $jsonfile['employees'][$id]= $all['employees'][$id];


         file_put_contents("../empdetails.json", json_encode($all));


    }

}


header("Location: ../view/view.php?model=model");


	}
}

$obj= new update2;
//creaating object

//header("Location: ../view/view.php?model=model");

?>